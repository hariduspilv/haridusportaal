const path = require('path');

module.exports =  {
  name: 'Storybook',
  path: 'https://edu.twn.ee/',
  ftp: {
    user: "vhost52758f5",
    password: "Erkki123",
    host: "www.twn.ee",
    port: 21,
    localRoot: path.resolve(__dirname, '../dist/haridusportaal-fe'),
    remoteRoot: '/',
    include: [".*", '*', '**/*'],
    deleteRemote: true,
    forcePasv: true    
  }    
}